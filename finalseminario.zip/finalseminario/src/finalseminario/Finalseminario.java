/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalseminario;


import CRUDs.CRUDCliente;
import CRUDs.CRUDProveedor;


/**
 *
 * @author Samayoa
 */
public class Finalseminario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    //----------------------------CRUD CLIENTE-------------------------------------
    //System.out.println("Cliente"+CRUDs.CRUDCliente.insert("Juan Amilcar", "Larias Mendez","45454545", "10994808", "Cambote", 1));
//      System.out.println("update="+CRUDs.CRUDCliente.update(1, "Amilcar", "Larias", "111111", "55555555", "Guate",1)); //IdProducto - "NombreDelProducto" - variablede arriba(precio) - Usuaurio          
//        System.out.println("anular="+CRUDs.CRUDCliente.anular(1,1));
//        System.out.println("eliminar="+CRUDs.CRUDCliente.eliminar(1,1)); //IdProducto - Usuaurio
//        System.out.println("Nombre= "+CRUDs.CRUDCliente.select(2).getNombre());

            /*Entorno de pruebas de consultas*/
//        for(int i=0;i<CRUDCliente.universo().size();i++){
//              /*sout[shorcutPara generar este medoto]*/
//              System.out.println("Nombre= "+CRUDCliente.universo().get(i).getNombre());
//              System.out.println("Apellido= "+CRUDCliente.universo().get(i).getApellido());
//              System.out.println("Nit= "+CRUDCliente.universo().get(i).getNit());
//              System.out.println("Direccion= "+CRUDCliente.universo().get(i).getDireccion());
//              System.out.println("Telefono= "+CRUDCliente.universo().get(i).getTelefono());
//          } 



        // TODO code application logic here

        //CRUD PROVEEDORES
        //INSERT
        //System.out.println("INSERTAR " + CRUDs.CRUDProveedor.insert("Diego", "Ciudad", "123456789", 1));
        //System.out.println("INSERTAR " + CRUDs.CRUDProveedor.insert("Juan", "Cambote", "987654321", 1));
        //UPDATE
        //System.out.println("ACTUALIZAR " + CRUDs.CRUDProveedor.update(1, "UPDATE", "UPDATE", "9999", 1));
        //SUSPENDER
        //System.out.println("ELIMINAR "+ CRUDs.CRUDProveedor.anular(2, 1));
        //SELECT UNIVERSO
//        for (int i = 0; i < CRUDProveedor.universo().size(); i++) {
//            System.out.println("1 = " + CRUDProveedor.universo().get(i).getNombre());
//            System.out.println("2 = " + CRUDProveedor.universo().get(i).getDireccion());
//            System.out.println("3 = " + CRUDProveedor.universo().get(i).getTelefono());
//
//        }

    }

}
